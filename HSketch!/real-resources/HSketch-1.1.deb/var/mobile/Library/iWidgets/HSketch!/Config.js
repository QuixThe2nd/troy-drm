var defaultColor = "black"; // Default color to draw in (change colors mid design by pinching screen)
var defaultSize = "20"; // Default color to draw in (change size mid design by pinching screen)
var defaultArt = ""; // Default art to have over your wallpaper